"use strict"
let col = localStorage.length;
function locah() {
    alert('количество записей в local storage: ' + col);
}