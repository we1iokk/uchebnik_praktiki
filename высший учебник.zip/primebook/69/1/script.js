"use strict"
let arr = [1,2,4,56,78];
let res = arr.values();
for (let elem of res){
  console.log(elem);
}
