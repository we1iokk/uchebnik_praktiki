"use strict"
let set = new Set([1, 2, 3, 6, 7, 4, 5]);
let res = set.values();
for(let elem of res){
  console.log(elem);
}