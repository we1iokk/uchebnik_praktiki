"use strict"
let map = new Map();
let array1 = [1,2,3,4,5,6,7,8,9,10];
let array2 = ['a', 'b', 'c', 'd', 'e', 'f'];
let array3 = [true, false];
map.set(array1, 'первый');
map.set(array2, 'второй');
map.set(array3, 'третий');

for (let [key, elem] of map){
    console.log(key);
}