"use strict"
let json = ['user1', 'user2', 'user3', 'user4', 'user5'];
let res = JSON.stringify(json);
console.log(res);