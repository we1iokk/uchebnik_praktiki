"use strict"
let a = document.querySelectorAll('p');
for (let entry of a) {
  console.log(entry);
}