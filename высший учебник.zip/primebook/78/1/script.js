"use strict"
let arr = [1, 2, 3, 'a', 'b', 'c'];
let str = JSON.stringify(arr);
console.log(str);